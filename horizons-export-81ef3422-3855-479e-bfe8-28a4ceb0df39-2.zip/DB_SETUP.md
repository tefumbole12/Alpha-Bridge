
# 🚀 Supabase & Backend Deployment Guide

This guide provides the **exact code** you need to copy-paste into your Supabase Dashboard to get the Master Class Registration system working.

---

## 1️⃣ Database Schema Setup (SQL)

Go to **Supabase Dashboard** > **SQL Editor**, paste the code below, and click **Run**.

