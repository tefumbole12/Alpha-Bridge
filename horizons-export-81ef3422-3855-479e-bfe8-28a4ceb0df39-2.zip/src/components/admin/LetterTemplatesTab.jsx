
// This file has been deprecated and removed.
import React from 'react';
const LetterTemplatesTab = () => null;
export default LetterTemplatesTab;
