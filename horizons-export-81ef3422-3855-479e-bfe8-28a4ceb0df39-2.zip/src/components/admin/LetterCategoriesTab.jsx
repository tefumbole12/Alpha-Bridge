
// This file has been deprecated and removed.
import React from 'react';
const LetterCategoriesTab = () => null;
export default LetterCategoriesTab;
