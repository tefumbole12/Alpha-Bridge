/**
 * Notification Service
 * Orchestrates dual-channel OTP delivery (Email + WhatsApp)
 */
import { sendOTPEmail } from './emailService';
import { sendWhatsAppOTP } from './wasenderService';
import { logger } from '@/utils/logger';

const MAX_RETRIES = 2;
const RETRY_DELAY = 2000; // 2 seconds

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const attemptSend = async (channel, func, ...args) => {
  let attempt = 0;
  let lastError = null;

  while (attempt <= MAX_RETRIES) {
    try {
      if (attempt > 0) {
        logger.info(`Retrying ${channel} (Attempt ${attempt + 1}/${MAX_RETRIES + 1})...`);
        await delay(RETRY_DELAY);
      }

      const result = await func(...args);
      
      if (result.success) {
        logger.logNotificationAttempt({ channel, status: 'SUCCESS', recipient: args[0] });
        return { success: true, error: null };
      } else {
        lastError = result.error || 'Unknown Error';
        logger.logNotificationAttempt({ channel, status: 'FAILED', error: lastError, recipient: args[0] });
      }

    } catch (err) {
      lastError = err.message;
      logger.logNotificationAttempt({ channel, status: 'EXCEPTION', error: lastError, recipient: args[0] });
    }
    
    attempt++;
  }

  return { success: false, error: lastError };
};

export const sendOTPViaDualChannels = async (email, phoneNumber, otpCode) => {
  logger.info(`Starting Dual Channel OTP Delivery`, { email, phoneNumber });

  // Start both channels concurrently
  const emailPromise = attemptSend('EMAIL', sendOTPEmail, email, otpCode);
  const whatsappPromise = attemptSend('WHATSAPP', sendWhatsAppOTP, phoneNumber, otpCode);

  // Wait for both to complete (settle)
  const [emailResult, whatsappResult] = await Promise.all([emailPromise, whatsappPromise]);

  // Determine final status
  let finalStatus = {
    success: false,
    emailSent: emailResult.success,
    whatsappSent: whatsappResult.success,
    channel: null,
    error: null
  };

  if (emailResult.success && whatsappResult.success) {
    finalStatus.success = true;
    finalStatus.channel = 'both';
  } else if (emailResult.success) {
    finalStatus.success = true;
    finalStatus.channel = 'email';
    finalStatus.error = `WhatsApp failed: ${whatsappResult.error}`;
  } else if (whatsappResult.success) {
    finalStatus.success = true;
    finalStatus.channel = 'whatsapp';
    finalStatus.error = `Email failed: ${emailResult.error}`;
  } else {
    finalStatus.success = false;
    finalStatus.channel = 'none';
    finalStatus.error = `Both channels failed. Email: ${emailResult.error}, WhatsApp: ${whatsappResult.error}`;
  }

  logger.info(`Dual Channel Result: ${finalStatus.channel}`, { status: finalStatus });
  return finalStatus;
};