
// Mock Service for Letter Management

const LETTERS_KEY = 'ab_letters';
const LETTER_RECIPIENTS_KEY = 'ab_letter_recipients';

const getLocalLetters = () => JSON.parse(localStorage.getItem(LETTERS_KEY) || '[]');
const saveLocalLetters = (data) => localStorage.setItem(LETTERS_KEY, JSON.stringify(data));

const getLocalRecipients = () => JSON.parse(localStorage.getItem(LETTER_RECIPIENTS_KEY) || '[]');
const saveLocalRecipients = (data) => localStorage.setItem(LETTER_RECIPIENTS_KEY, JSON.stringify(data));

export const createLetter = async (letterData, recipients) => {
    await new Promise(resolve => setTimeout(resolve, 600));
    
    const letters = getLocalLetters();
    const letterId = `let-${Date.now()}`;
    
    const newLetter = {
        id: letterId,
        ...letterData,
        sent_at: new Date().toISOString(),
        is_archived: false
    };
    
    letters.push(newLetter);
    saveLocalLetters(letters);

    const allRecipients = getLocalRecipients();
    const newRecipients = recipients.map(r => ({
        id: `lr-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        letter_id: letterId,
        recipient_id: r.id,
        recipient_type: r.type,
        recipient_name: r.name,
        is_read: false,
        created_at: new Date().toISOString()
    }));
    
    saveLocalRecipients([...allRecipients, ...newRecipients]);
    return newLetter;
};

export const getLetterHistory = async () => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const letters = getLocalLetters();
    const recipients = getLocalRecipients();
    
    return letters.map(l => {
        const recs = recipients.filter(r => r.letter_id === l.id);
        return {
            ...l,
            recipient_count: recs.length,
            read_count: recs.filter(r => r.is_read).length
        };
    }).sort((a,b) => new Date(b.sent_at) - new Date(a.sent_at));
};

export const getLettersByRecipient = async (recipientId) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const recipients = getLocalRecipients().filter(r => r.recipient_id === recipientId);
    const letters = getLocalLetters();
    
    return recipients.map(r => {
        // Fixed: Renamed 'let' to 'letterItem' to avoid reserved keyword conflict
        const l = letters.find(letterItem => letterItem.id === r.letter_id);
        return { ...l, ...r };
    }).filter(l => l.id);
};

export const deleteLetter = async (id) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    let letters = getLocalLetters();
    letters = letters.filter(l => l.id !== id);
    saveLocalLetters(letters);
    
    let recipients = getLocalRecipients();
    recipients = recipients.filter(r => r.letter_id !== id);
    saveLocalRecipients(recipients);
    return true;
};
